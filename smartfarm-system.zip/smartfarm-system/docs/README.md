# SmartFarm Monitor – Hệ thống giám sát trạm cảm biến nông trại

Hệ thống hỗ trợ kỹ sư hạ tầng SmartFarm lọc log máy chủ tự động và quản lý danh sách thiết bị tại các trạm cảm biến.

## Hướng dẫn chạy script

Mở PowerShell, di chuyển vào thư mục `scripts/` rồi chạy:

```powershell
cd smartfarm-system/scripts
.\auto_report.ps1
```

Nếu bị chặn bởi ExecutionPolicy:

```powershell
powershell -ExecutionPolicy Bypass -File .\auto_report.ps1
```

Kết quả được ghi vào `backup/bao-cao-su-co.txt`.

## Checklist kiểm tra thiết bị

- [x] Tạo cây thư mục `smartfarm-system` (docs, scripts, data, backup)
- [x] Viết script `auto_report.ps1` lọc log CRITICAL/ERROR
- [x] Làm sạch mã linh kiện bằng TRIM và tra tên thiết bị bằng VLOOKUP
- [ ] Kiểm tra pin và tín hiệu trạm sensor-03
- [ ] Đẩy repository lên GitHub và nộp link

## Bảng thông số phần cứng

| Tên thiết bị | Đơn giá (VNĐ) | Loại storage |
| --- | ---: | :---: |
| Raspberry Pi 4 Model B | 1.450.000 | SSD |
| Intel NUC i3 | 6.200.000 | SSD |
| Orange Pi 5 | 2.300.000 | SSD |
| Dell Optiplex Micro | 5.400.000 | HDD |
| Mini PC Fanless N100 | 4.200.000 | SSD |
| Synology DS220j NAS | 3.900.000 | HDD |

## Phân tích hệ thống

### Mô hình IPO của chức năng lọc log

| Thành phần | Nội dung |
| --- | --- |
| **Input** | File nhật ký `log-he-thong.log` (các dòng dạng ngày giờ, mức độ, thiết bị, nội dung) |
| **Process** | `Get-Content` đọc log, qua Pipeline `\|` đến `Select-String` lọc dòng chứa `CRITICAL` hoặc `ERROR`, nối vào báo cáo bằng `>>`, rồi đếm số dòng lỗi bằng `Measure-Object` |
| **Output** | File `backup/bao-cao-su-co.txt` gồm tiêu đề, ngày giờ, các dòng sự cố và `TONG SO SU CO` |

### Phân loại DIKW

| Phát biểu | Tầng DIKW | Lý do |
| --- | --- | --- |
| (a) "Quyết định thay modem trạm sensor-03 trước thứ Sáu." | **Wisdom** | Là quyết định hành động dựa trên hiểu biết đã có |
| (b) "2026-10-12 08:15:01 [ERROR] sensor-03 Connection TIMEOUT after 30s" | **Data** | Dòng log thô, chưa được xử lý hay gán ý nghĩa |
| (c) "Hôm nay hệ thống ghi nhận 8 sự cố, trong đó 4 sự cố đến từ trạm sensor-03." | **Information** | Dữ liệu đã được tổng hợp, đếm và đặt vào ngữ cảnh |
| (d) "Trạm sensor-03 hay mất kết nối vào buổi chiều do sóng yếu, nên cần lắp thêm anten." | **Knowledge** | Quy luật và nguyên nhân rút ra từ nhiều thông tin |
