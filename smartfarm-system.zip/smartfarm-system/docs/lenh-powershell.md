# Lệnh PowerShell dùng trong bài (Chức năng 1)

Tạo cây thư mục bằng 1 dòng lệnh duy nhất:

```powershell
New-Item -ItemType Directory -Path smartfarm-system\docs, smartfarm-system\scripts, smartfarm-system\data, smartfarm-system\backup
```

Đứng trong `smartfarm-system\data`, tạo file `.env` ở thư mục gốc bằng đường dẫn tương đối và ẩn file:

```powershell
cd smartfarm-system\data
Set-Content -Path ..\.env -Value "DB_PASSWORD=demo_123456"
(Get-Item ..\.env -Force).Attributes = 'Hidden'
```
